package com.org.entity;

public class theme {
	public String themename;// 主题名字

	@Override
	public String toString() {
		return "theme [themename=" + themename + "]";
	}

}
