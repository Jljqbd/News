package com.org.entity;

public class Themenews {
	public String themename;
	public String newstime;
	public String newsnum;
}
